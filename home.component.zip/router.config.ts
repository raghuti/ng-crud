import { Routes } from "@angular/router";
import { AddComponent } from "./add.component";
import { UpdateComponent } from "./update.component";
import { HomeComponent } from "./home.component";

export const appRoutes:Routes = [
    {
        path : 'add',
        component : AddComponent
    },
    {
        path : 'update/:id',
        component : UpdateComponent
    },
    {
        path : 'home',
        component : HomeComponent
    }
]