import { Component } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { HeroServices } from './app.services';

@Component({
template : `
<div class="panel panel-default">
    <div class="panel-heading">
      {{ appTitle }}
    </div>
    <div class="panel-body">
      <form [formGroup]="angForm" novalidate>
        <div class="form-group">
          <label class="col-md-4">Hero Name</label>
          <input type="text" class="form-control" formControlName="title" #title />
        </div>
        <div *ngIf="angForm.controls['title'].invalid && (angForm.controls['title'].dirty || angForm.controls['title'].touched)" class="alert alert-danger">
          <div *ngIf="angForm.controls['title'].errors.required">
            Title is required.
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-4">Hero Power: <span #log></span></label>
          <input type="range" min="0" max="10" class="form-control" (input)="log.innerHTML = power.value"  formControlName="power" #power/>
        </div>
        <div *ngIf="angForm.controls['power'].invalid && (angForm.controls['power'].dirty || angForm.controls['power'].touched)" class="alert alert-danger">
          <div *ngIf="angForm.controls['power'].errors.required">
            Power is required.
          </div>
        </div>
          <div class="form-group">
            <button type="button" (click)="addHero(title.value, power.value)" [disabled]="angForm.pristine || angForm.invalid" class="btn btn-primary">Add</button>
          </div>
      </form>
    </div>
  </div>
`
})
export class AddComponent {
  appTitle = 'Add Heroes' ;
  angForm: FormGroup;
  constructor(private heroservice: HeroServices, private fb: FormBuilder){
    this.createForm();
  }
  createForm() {
    this.angForm = this.fb.group({
      title: ['', Validators.required ],
      power: ['', Validators.required ]
   });
  }

  addHero(title, power) {
    this.heroservice.addHero(title, power);
  }

}
