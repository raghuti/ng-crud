import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { map } from 'rxjs/operators';

@Injectable()
export class HeroServices{
constructor(private http: HttpClient){};
getHeroes() {
        const uri = 'http://localhost:2525/heroes/';
        return this.http.get(uri).pipe( map(res => res) );
};
editHero(id) {
        const uri = 'http://localhost:2525/heroes/edit/' + id;
        return this.http.get(uri).pipe( map(res => res) );
};
addHero(title, power) {
    const uri = 'http://localhost:2525/heroes/add';
    const obj = {
        title: title,
        power: power
    };
    this.http.post(uri, obj).subscribe(res => console.log('Done'));
};
updateHero(title, power, id){
    const uri = 'http://localhost:2525/heroes/update/' + id;
    const obj = {
      title: title,
      power: power
    };
    console.log('update request', id);
    this.http.post(uri, obj).subscribe(res => console.log(res));
  };

  deleteHero(id){
    const uri = 'http://localhost:2525/heroes/delete/' + id;
    return this.http.get(uri).pipe( map(res => res) );
  }

}
