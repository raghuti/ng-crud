import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HeroServices } from './app.services';

@Component({
  selector: 'app-home-heroes',
  template: `
  <table class="table table-hover">
  <thead>
  <tr>
      <td>Hero Title</td>
      <td>Hero Power</td>
      <td colspan="2">Modify</td>
  </tr>
  </thead>

  <tbody>
      <tr *ngFor="let hero of heroes">
          <td>{{ hero.title }}</td>
          <td>{{ hero.power }}</td>
          <td><a [routerLink]="['/update', hero._id]" class="btn btn-primary">Edit</a></td>
          <td><button (click)="deleteHero(hero._id)"  class="btn btn-danger">Delete</button></td>
      </tr>
  </tbody>
</table>
  `
})
export class HomeComponent implements OnInit {
  title = 'Heroes Home';
  heroes: any;

  constructor(private http: HttpClient, private service: HeroServices){}

  ngOnInit(){
    this.getHeroes();
  }

  getHeroes() {
    this.service.getHeroes().subscribe(res => {
      this.heroes = res;
    });
  };
  deleteHero(id) {
    // console.log(id);
    this.service.deleteHero(id).subscribe(res => {
      console.log('Deleted');
    });
}
}
