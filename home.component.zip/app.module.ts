import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HeroServices } from './app.services';
import { NgModule } from '@angular/core';
import { AddComponent } from './add.component';
import { UpdateComponent } from './update.component';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule  } from '@angular/forms';
import { appRoutes } from './router.config';
import { HomeComponent } from './home.component';



@NgModule({
  declarations: [
    AppComponent, AddComponent, UpdateComponent, HomeComponent, 
  ],
  imports: [
    BrowserModule, HttpClientModule, RouterModule.forRoot(appRoutes), ReactiveFormsModule
  ],
  providers: [HeroServices],
  bootstrap: [AppComponent]
})
export class AppModule { }
